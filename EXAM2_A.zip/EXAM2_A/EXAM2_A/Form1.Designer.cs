﻿namespace EXAM2_A
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnFreeze1 = new System.Windows.Forms.Button();
            this.btnFreeze2 = new System.Windows.Forms.Button();
            this.btnFreeze3 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnTotScore = new System.Windows.Forms.Button();
            this.btnCurrentScore = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.radTwenty = new System.Windows.Forms.RadioButton();
            this.radFive = new System.Windows.Forms.RadioButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.timesPerSecondToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fiveSpeedmnu = new System.Windows.Forms.ToolStripMenuItem();
            this.twentySpeedmnu = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.lstScore = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.picBox3 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.unfreeze3Cmnu = new System.Windows.Forms.ToolStripMenuItem();
            this.picBox2 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.unfreeze2Cmnu = new System.Windows.Forms.ToolStripMenuItem();
            this.picBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.unfreeze1Cmnu = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnFreeze1
            // 
            this.btnFreeze1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreeze1.Location = new System.Drawing.Point(172, 750);
            this.btnFreeze1.Name = "btnFreeze1";
            this.btnFreeze1.Size = new System.Drawing.Size(144, 47);
            this.btnFreeze1.TabIndex = 3;
            this.btnFreeze1.Text = "Freeze";
            this.btnFreeze1.UseVisualStyleBackColor = true;
            this.btnFreeze1.Click += new System.EventHandler(this.BtnFreeze1_Click);
            // 
            // btnFreeze2
            // 
            this.btnFreeze2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreeze2.Location = new System.Drawing.Point(476, 750);
            this.btnFreeze2.Name = "btnFreeze2";
            this.btnFreeze2.Size = new System.Drawing.Size(144, 47);
            this.btnFreeze2.TabIndex = 4;
            this.btnFreeze2.Text = "Freeze";
            this.btnFreeze2.UseVisualStyleBackColor = true;
            this.btnFreeze2.Click += new System.EventHandler(this.BtnFreeze2_Click);
            // 
            // btnFreeze3
            // 
            this.btnFreeze3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFreeze3.Location = new System.Drawing.Point(775, 750);
            this.btnFreeze3.Name = "btnFreeze3";
            this.btnFreeze3.Size = new System.Drawing.Size(136, 47);
            this.btnFreeze3.TabIndex = 5;
            this.btnFreeze3.Text = "Freeze";
            this.btnFreeze3.UseVisualStyleBackColor = true;
            this.btnFreeze3.Click += new System.EventHandler(this.BtnFreeze3_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.groupBox1.Controls.Add(this.btnTotScore);
            this.groupBox1.Controls.Add(this.btnCurrentScore);
            this.groupBox1.Controls.Add(this.btnPlay);
            this.groupBox1.Controls.Add(this.radTwenty);
            this.groupBox1.Controls.Add(this.radFive);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(146, 294);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(800, 195);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select a Speed:";
            // 
            // btnTotScore
            // 
            this.btnTotScore.Location = new System.Drawing.Point(543, 119);
            this.btnTotScore.Name = "btnTotScore";
            this.btnTotScore.Size = new System.Drawing.Size(196, 49);
            this.btnTotScore.TabIndex = 12;
            this.btnTotScore.Text = "Total Score";
            this.btnTotScore.UseVisualStyleBackColor = true;
            this.btnTotScore.Click += new System.EventHandler(this.BtnTotScore_Click);
            // 
            // btnCurrentScore
            // 
            this.btnCurrentScore.Location = new System.Drawing.Point(543, 49);
            this.btnCurrentScore.Name = "btnCurrentScore";
            this.btnCurrentScore.Size = new System.Drawing.Size(196, 49);
            this.btnCurrentScore.TabIndex = 11;
            this.btnCurrentScore.Text = "Current Score";
            this.btnCurrentScore.UseVisualStyleBackColor = true;
            this.btnCurrentScore.Click += new System.EventHandler(this.BtnCurrentScore);
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(370, 74);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(119, 94);
            this.btnPlay.TabIndex = 2;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.BtnPlay_Click);
            // 
            // radTwenty
            // 
            this.radTwenty.AutoSize = true;
            this.radTwenty.Location = new System.Drawing.Point(35, 133);
            this.radTwenty.Name = "radTwenty";
            this.radTwenty.Size = new System.Drawing.Size(288, 35);
            this.radTwenty.TabIndex = 1;
            this.radTwenty.TabStop = true;
            this.radTwenty.Text = "20 times per second";
            this.radTwenty.UseVisualStyleBackColor = true;
            // 
            // radFive
            // 
            this.radFive.AutoSize = true;
            this.radFive.Location = new System.Drawing.Point(35, 80);
            this.radFive.Name = "radFive";
            this.radFive.Size = new System.Drawing.Size(273, 35);
            this.radFive.TabIndex = 0;
            this.radFive.TabStop = true;
            this.radFive.Text = "5 times per second";
            this.radFive.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.timesPerSecondToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1105, 40);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // timesPerSecondToolStripMenuItem
            // 
            this.timesPerSecondToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fiveSpeedmnu,
            this.twentySpeedmnu});
            this.timesPerSecondToolStripMenuItem.Name = "timesPerSecondToolStripMenuItem";
            this.timesPerSecondToolStripMenuItem.Size = new System.Drawing.Size(94, 36);
            this.timesPerSecondToolStripMenuItem.Text = "Speed";
            // 
            // fiveSpeedmnu
            // 
            this.fiveSpeedmnu.Name = "fiveSpeedmnu";
            this.fiveSpeedmnu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.fiveSpeedmnu.Size = new System.Drawing.Size(415, 38);
            this.fiveSpeedmnu.Text = "5 times per second";
            this.fiveSpeedmnu.Click += new System.EventHandler(this.FiveSpeedmnu_Click);
            // 
            // twentySpeedmnu
            // 
            this.twentySpeedmnu.Name = "twentySpeedmnu";
            this.twentySpeedmnu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H)));
            this.twentySpeedmnu.Size = new System.Drawing.Size(415, 38);
            this.twentySpeedmnu.Text = "20 times per second";
            this.twentySpeedmnu.Click += new System.EventHandler(this.TwentySpeedmnu_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.Timer3_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(132, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(496, 155);
            this.label1.TabIndex = 8;
            this.label1.Text = "Ways to Play the Matching Game:\r\n1. Select a Speed and Press Play.\r\n2. Select a s" +
    "peed from the menu Speed.\r\n3. Ctrl + L for low speed game.\r\n4. Ctrl + H for high" +
    " speed game.";
            // 
            // lstScore
            // 
            this.lstScore.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lstScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstScore.FormattingEnabled = true;
            this.lstScore.ItemHeight = 31;
            this.lstScore.Location = new System.Drawing.Point(700, 77);
            this.lstScore.Name = "lstScore";
            this.lstScore.Size = new System.Drawing.Size(246, 190);
            this.lstScore.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(695, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(179, 31);
            this.label2.TabIndex = 10;
            this.label2.Text = "Score Board: ";
            // 
            // picBox3
            // 
            this.picBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picBox3.ContextMenuStrip = this.contextMenuStrip3;
            this.picBox3.Image = global::EXAM2_A.Properties.Resources.Cherry;
            this.picBox3.Location = new System.Drawing.Point(746, 534);
            this.picBox3.Name = "picBox3";
            this.picBox3.Size = new System.Drawing.Size(200, 200);
            this.picBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox3.TabIndex = 2;
            this.picBox3.TabStop = false;
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unfreeze3Cmnu});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(187, 40);
            // 
            // unfreeze3Cmnu
            // 
            this.unfreeze3Cmnu.Name = "unfreeze3Cmnu";
            this.unfreeze3Cmnu.Size = new System.Drawing.Size(186, 36);
            this.unfreeze3Cmnu.Text = "Unfreeze";
            this.unfreeze3Cmnu.Click += new System.EventHandler(this.Unfreeze3Cmnu_Click);
            // 
            // picBox2
            // 
            this.picBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picBox2.ContextMenuStrip = this.contextMenuStrip2;
            this.picBox2.Image = global::EXAM2_A.Properties.Resources.Orange;
            this.picBox2.Location = new System.Drawing.Point(447, 534);
            this.picBox2.Name = "picBox2";
            this.picBox2.Size = new System.Drawing.Size(200, 200);
            this.picBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox2.TabIndex = 1;
            this.picBox2.TabStop = false;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unfreeze2Cmnu});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(187, 40);
            // 
            // unfreeze2Cmnu
            // 
            this.unfreeze2Cmnu.Name = "unfreeze2Cmnu";
            this.unfreeze2Cmnu.Size = new System.Drawing.Size(186, 36);
            this.unfreeze2Cmnu.Text = "Unfreeze";
            this.unfreeze2Cmnu.Click += new System.EventHandler(this.Unfreeze2Cmnu_Click);
            // 
            // picBox1
            // 
            this.picBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.picBox1.Image = global::EXAM2_A.Properties.Resources.Watermelon;
            this.picBox1.Location = new System.Drawing.Point(146, 534);
            this.picBox1.Name = "picBox1";
            this.picBox1.Size = new System.Drawing.Size(200, 200);
            this.picBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox1.TabIndex = 0;
            this.picBox1.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unfreeze1Cmnu});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(187, 40);
            // 
            // unfreeze1Cmnu
            // 
            this.unfreeze1Cmnu.Name = "unfreeze1Cmnu";
            this.unfreeze1Cmnu.Size = new System.Drawing.Size(186, 36);
            this.unfreeze1Cmnu.Text = "Unfreeze";
            this.unfreeze1Cmnu.Click += new System.EventHandler(this.Unfreeze1Cmnu_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1105, 906);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstScore);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnFreeze3);
            this.Controls.Add(this.btnFreeze2);
            this.Controls.Add(this.btnFreeze1);
            this.Controls.Add(this.picBox3);
            this.Controls.Add(this.picBox2);
            this.Controls.Add(this.picBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnFreeze1;
        private System.Windows.Forms.Button btnFreeze2;
        private System.Windows.Forms.Button btnFreeze3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.RadioButton radTwenty;
        private System.Windows.Forms.RadioButton radFive;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem timesPerSecondToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fiveSpeedmnu;
        private System.Windows.Forms.ToolStripMenuItem twentySpeedmnu;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstScore;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnTotScore;
        private System.Windows.Forms.Button btnCurrentScore;
        private System.Windows.Forms.PictureBox picBox3;
        private System.Windows.Forms.PictureBox picBox2;
        private System.Windows.Forms.PictureBox picBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem unfreeze1Cmnu;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem unfreeze3Cmnu;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem unfreeze2Cmnu;
    }
}

