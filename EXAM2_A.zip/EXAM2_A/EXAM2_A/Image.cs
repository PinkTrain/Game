﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAM2_A
{
    public class Image
    {
        private ImageType imageType;
        private Bitmap bitmapImage;

        public Image(ImageType type, Bitmap bitmap)//constructor for Image class
        {
            imageType = type;
            bitmapImage = bitmap;
        }

        public ImageType ImageType => imageType;

        public Bitmap BitmapImage => bitmapImage;

    }
}
