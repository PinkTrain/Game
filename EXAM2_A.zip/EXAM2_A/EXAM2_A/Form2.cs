﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EXAM2_A
{
    public partial class Form2 : Form
    {
        public Form2(List<int> scores)
        {
            InitializeComponent();
            int count = 1;
            var total = 0;
            foreach (var score in scores)
            {
                var detail = string.Format("Game# {0}: {1}", count++.ToString(), score);
                lstCurScore.Items.Add(detail);
                total += score;
            }
            lstTotalScore.Items.Add(total);
        }
    }
}
