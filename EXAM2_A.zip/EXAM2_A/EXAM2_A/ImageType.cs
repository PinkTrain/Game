﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EXAM2_A
{
    public enum ImageType
    {
        Banana,
        Cherry,
        Orange,
        Watermelon
    };  
}
