﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EXAM2_A
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        int count = 0;
        int score = 0;

        //current images for each picture box
        private ImageType currentImage1;
        private ImageType currentImage2;
        private ImageType currentImage3;

        //List that contains the paths of all Bitmap images
        private List<Image> paths = new List<Image>();

        public Form1()
        {
            InitializeComponent();
            paths.Add(new Image(ImageType.Banana, Properties.Resources.Banana));
            paths.Add(new Image(ImageType.Cherry, Properties.Resources.Cherry));
            paths.Add(new Image(ImageType.Orange, Properties.Resources.Orange));
            paths.Add(new Image(ImageType.Watermelon, Properties.Resources.Watermelon));
        }

        public Image GetRandomImage()
        {
            return paths[(random.Next(0, paths.Count))];
        }

        private void BtnPlay_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            count = 0;
            GetSpeed();
        }

        private void GetSpeed()
        {
            if (radFive.Checked)
            {
                timer1.Interval = 1000 / 5;
                timer2.Interval = 1000 / 5;
                timer3.Interval = 1000 / 5;
            }
            else if (radTwenty.Checked)
            {
                timer1.Interval = 1000 / 20;
                timer2.Interval = 1000 / 20;
                timer3.Interval = 1000 / 20;
            }
            else
            {
                timer1.Interval = 1000;
                timer2.Interval = 1000;
                timer3.Interval = 1000;
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            var image = GetRandomImage();
            picBox1.Image = image.BitmapImage;
            currentImage1 = image.ImageType;
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            var image = GetRandomImage();
            picBox2.Image = image.BitmapImage;
            currentImage2 = image.ImageType;
        }

        private void Timer3_Tick(object sender, EventArgs e)
        {
            var image = GetRandomImage();
            picBox3.Image = image.BitmapImage;
            currentImage3 = image.ImageType;
        }

        private void BtnFreeze1_Click(object sender, EventArgs e)
        {
            count++;
            timer1.Enabled = false;
            Winner_Loser();
        }

        private void BtnFreeze2_Click(object sender, EventArgs e)
        {
            count++;
            timer2.Enabled = false;
            Winner_Loser();
        }

        private void BtnFreeze3_Click(object sender, EventArgs e)
        {
            count++;
            timer3.Enabled = false;
            Winner_Loser();
        }

        private int Game()
        {
            int result = 1;
            if (currentImage1 == currentImage2 && currentImage2 == currentImage3)
                result = 3;
            else if ((currentImage1 == currentImage2 && currentImage2 != currentImage3) ||
                        (currentImage2 == currentImage3 && currentImage3 != currentImage1) ||
                        (currentImage1 == currentImage3 && currentImage3 != currentImage2))
                result = 2;
            return result;
        }

        private int Winner_Loser()
        {
            if (count == 3)
            {
                if (Game() == 3)
                {
                    score += 10;
                    MessageBox.Show("Congrats! You earned 10 points.");
                }
                //if pic1 = pic2 = 3 "Congrats! You earned 10 points."
                else if (Game() == 2)
                {
                    score += 5;
                    //if pic1 = pic2 or pic2 = pic3 or pic1 = pic3 "You earned 5 points."
                    MessageBox.Show("You earned 5 points.");
                }
                else
                {
                    score += 0;
                    //if pic1 != pic2 or pic1 != pic3 or pic1 != pic3 "Game over!"
                    MessageBox.Show("Game over!");
                }
            }
            return score;           
        }

        private void FiveSpeedmnu_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            timer1.Interval = 1000 / 5;
            timer2.Interval = 1000 / 5;
            timer3.Interval = 1000 / 5;
        }

        private void TwentySpeedmnu_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            timer1.Interval = 1000 / 20;
            timer2.Interval = 1000 / 20;
            timer3.Interval = 1000 / 20;
        }

        private void BtnCurrentScore(object sender, EventArgs e)
        {
            lstScore.Items.Add(score);
            score = 0;
        }

        private void BtnTotScore_Click(object sender, EventArgs e)
        {
            var scores = new List<int>();
            foreach (var item in lstScore.Items)
            {
                scores.Add(int.Parse(item.ToString()));
            }


            Form2 f2 = new Form2(scores);
            f2.Show();            
        }

        private void Unfreeze1Cmnu_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Start();
            count = 0;
        }

        private void Unfreeze2Cmnu_Click(object sender, EventArgs e)
        {
            timer2.Enabled = true;
            timer2.Start();
            count = 0;
        }

        private void Unfreeze3Cmnu_Click(object sender, EventArgs e)
        {
            timer3.Enabled = true;
            timer3.Start();
            count = 0;
            //Winner_Loser();
        }
    }
}
